asset-print_label
<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../config/db.php';

$code      = trim($_GET['code'] ?? '');
$codes_raw = trim($_GET['codes'] ?? '');

$codes = [];
if ($code) {
    $codes = [$code];
} elseif ($codes_raw) {
    $codes = array_filter(array_map('trim', explode(',', $codes_raw)));
}

if (!$codes) {
    header('Location: ' . APP_URL . '/asset_list');
    exit;
}

$db = getDB();
$placeholders = implode(',', array_fill(0, count($codes), '?'));
$stmt = $db->prepare("SELECT asset_code, name FROM assets WHERE asset_code IN ($placeholders)");
$stmt->execute(array_values($codes));
$assets = [];
while ($row = $stmt->fetch()) {
    $assets[$row['asset_code']] = $row['name'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Print Label</title>
<style>
#print-area { display: none; }
@media print {
    @page { size: 70mm 50mm; margin: 0; }
    html, body { margin: 0 !important; padding: 0 !important; width: 70mm !important; background: #fff !important; }

    .no-print { display: none !important; }

    #print-area { display: block !important; width: 70mm !important; }

    .print-label {
        width: 70mm; height: 50mm;
        display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1.5mm; padding: 3mm;
        box-sizing: border-box;
        page-break-after: always; break-after: page;
        page-break-inside: avoid; break-inside: avoid; overflow: hidden;
    }
    .print-label:last-child { page-break-after: auto; break-after: auto; }

    .print-qr-wrap { display: flex; flex-direction: column; align-items: center; flex-shrink: 0; }
    .print-simrs { font-family: Arial; font-size: 13pt; font-weight: 900; letter-spacing: 3px; color: #000; margin-bottom: 1.5mm; }
    .print-label img { width: 26mm; height: 26mm; flex-shrink: 0; display: block; }
    .print-label-info { text-align: center; }
    .print-label-code { font-family: Arial; font-size: 15pt; font-weight: 900; letter-spacing: 1px; word-break: break-all; }
    .print-label-name { font-family: Arial; font-size: 10pt; font-weight: 700; color: #333; margin-top: 1.5mm; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .print-label-loc  { font-family: Arial; font-size: 8pt; font-weight: 600; color: #555; margin-top: 1mm; }
}
</style>
</head>
<body>

<div class="screen-controls no-print">
    <div class="info">
        <strong>Print Label Aset</strong> &bull; <?= count($codes) ?> label &bull; Ukuran: 70×50mm
    </div>
    <button class="btn-print" onclick="window.print()">🖨️ Print Sekarang</button>
</div>

<div id="loading-overlay" class="no-print" style="position:fixed;inset:0;background:rgba(255,255,255,.9);display:flex;align-items:center;justify-content:center;z-index:999;font-size:16px;color:#1a237e;font-weight:700;">
    ⏳ Memuat QR Code...
</div>

<div class="labels-preview">
    <?php foreach ($codes as $c):
        if (!isset($assets[$c])) continue;
        $name = $assets[$c];
        $qr_url = APP_URL . '/api/generate_qr.php?code=' . urlencode($c);
    ?>
    <div class="label-card">
        <div class="simrs">SIMRS</div>
        <img src="<?= $qr_url ?>" alt="<?= htmlspecialchars($c, ENT_QUOTES, 'UTF-8') ?>">
        <div class="code"><?= htmlspecialchars($c, ENT_QUOTES, 'UTF-8') ?></div>
        <?php if ($name): ?>
        <div class="name"><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>

<script>
function waitForImages(callback) {
    const imgs = document.querySelectorAll('img');
    let loaded = 0;
    const total = imgs.length;
    if (total === 0) { callback(); return; }

    imgs.forEach(img => {
        if (img.complete && img.naturalWidth > 0) {
            loaded++;
            if (loaded === total) callback();
        } else {
            img.addEventListener('load', () => {
                loaded++;
                if (loaded === total) callback();
            });
            img.addEventListener('error', () => {
                loaded++;
                if (loaded === total) callback();
            });
        }
    });
}

if (document.referrer || window.opener) {
    window.addEventListener('load', function() {
        waitForImages(function() {
            const overlay = document.getElementById('loading-overlay');
            if (overlay) overlay.style.display = 'none';
            setTimeout(() => window.print(), 200);
        });
    });
} else {
    window.addEventListener('load', function() {
        waitForImages(function() {
            const overlay = document.getElementById('loading-overlay');
            if (overlay) overlay.style.display = 'none';
        });
    });
}
</script>
</body>
</html>