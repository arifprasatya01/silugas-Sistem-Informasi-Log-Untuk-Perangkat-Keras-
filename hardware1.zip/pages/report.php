<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
define('PAGE_TITLE', 'Laporan');
$db = getDB();

// Filters
$type      = $_GET['type'] ?? '';
$status    = $_GET['status'] ?? '';
$building  = cleanInt($_GET['building'] ?? 0);
$date_from = $_GET['date_from'] ?? '';
$date_to   = $_GET['date_to'] ?? '';
$report_type = $_GET['report_type'] ?? 'assets'; // assets | maintenance

$buildings = $db->query("SELECT id, name FROM buildings ORDER BY name")->fetchAll();
$type_labels = [
    'komputer'=>'Komputer','laptop'=>'Laptop','printer'=>'Printer',
    'scanner'=>'Scanner','server'=>'Server','network'=>'Network','lainnya'=>'Lainnya'
];

// ── ASSETS REPORT ──────────────────────────────────────
$assets = [];
if ($report_type === 'assets') {
    $where = ["a.is_registered = 1"];
    $params = [];
    if ($type)     { $where[] = "a.type = ?"; $params[] = $type; }
    if ($status)   { $where[] = "a.condition_status = ?"; $params[] = $status; }
    if ($building) { $where[] = "a.building_id = ?"; $params[] = $building; }

    $stmt = $db->prepare("
        SELECT a.*, b.name as building_name, r.name as room_name, u.name as registered_by_name
        FROM assets a
        LEFT JOIN buildings b ON b.id = a.building_id
        LEFT JOIN rooms r ON r.id = a.room_id
        LEFT JOIN users u ON u.id = a.registered_by
        WHERE " . implode(' AND ', $where) . "
        ORDER BY a.asset_code
    ");
    $stmt->execute($params);
    $assets = $stmt->fetchAll();
}

// ── MAINTENANCE REPORT ─────────────────────────────────
$maintenance = [];
if ($report_type === 'maintenance') {
    $where = ["1=1"];
    $params = [];
    if ($date_from) { $where[] = "ml.performed_at >= ?"; $params[] = $date_from . ' 00:00:00'; }
    if ($date_to)   { $where[] = "ml.performed_at <= ?"; $params[] = $date_to . ' 23:59:59'; }
    if ($building)  { $where[] = "a.building_id = ?"; $params[] = $building; }
    if ($type)      { $where[] = "a.type = ?"; $params[] = $type; }

    $stmt = $db->prepare("
        SELECT ml.*, a.asset_code, a.name as asset_name, a.type as asset_type,
               b.name as building_name, r.name as room_name, u.name as user_name
        FROM maintenance_logs ml
        JOIN assets a ON a.id = ml.asset_id
        LEFT JOIN buildings b ON b.id = a.building_id
        LEFT JOIN rooms r ON r.id = a.room_id
        JOIN users u ON u.id = ml.performed_by
        WHERE " . implode(' AND ', $where) . "
        ORDER BY ml.performed_at DESC
    ");
    $stmt->execute($params);
    $maintenance = $stmt->fetchAll();
}

// ── SEMESTER REPORT ──
$sem_type     = $_GET['sem_type'] ?? '';
$sem_building = cleanInt($_GET['sem_building'] ?? 0);
$sem_semester = $_GET['sem_semester'] ?? '1';
$sem_year     = cleanInt($_GET['sem_year'] ?? date('Y'));
if (!$sem_year) { $sem_year = (int)date('Y'); }

if ($sem_semester == '2') {
    $sem_start = "$sem_year-07-01 00:00:00";
    $sem_end   = "$sem_year-12-31 23:59:59";
    $sem_label = "Semester 2 (Juli - Desember $sem_year)";
} elseif ($sem_semester == 'all') {
    $sem_start = "$sem_year-01-01 00:00:00";
    $sem_end   = "$sem_year-12-31 23:59:59";
    $sem_label = "Semua Semester (Januari - Desember $sem_year)";
} else {
    $sem_start = "$sem_year-01-01 00:00:00";
    $sem_end   = "$sem_year-06-30 23:59:59";
    $sem_label = "Semester 1 (Januari - Juni $sem_year)";
}

$sem_where = ["a.is_registered = 1", "a.registered_at BETWEEN ? AND ?"];
$sem_params = [$sem_start, $sem_end];
if ($sem_type)     { $sem_where[] = "a.type = ?"; $sem_params[] = $sem_type; }
if ($sem_building) { $sem_where[] = "a.building_id = ?"; $sem_params[] = $sem_building; }
$sem_where_sql = implode(' AND ', $sem_where);

$stmt = $db->prepare("
    SELECT a.*, b.name as building_name, r.name as room_name
    FROM assets a
    LEFT JOIN buildings b ON b.id = a.building_id
    LEFT JOIN rooms r ON r.id = a.room_id
    WHERE $sem_where_sql
    ORDER BY b.name, r.name, a.asset_code
");
$stmt->execute($sem_params);
$semester_data = $stmt->fetchAll();

$stmt = $db->prepare("
    SELECT COALESCE(b.name, 'Tanpa Gedung') as building_name, COUNT(a.id) as total
    FROM assets a
    LEFT JOIN buildings b ON b.id = a.building_id
    WHERE $sem_where_sql
    GROUP BY b.id, b.name
    ORDER BY total DESC
");
$stmt->execute($sem_params);
$by_building = $stmt->fetchAll();

$stmt = $db->prepare("
    SELECT COALESCE(b.name, 'Tanpa Gedung') as building_name,
           COALESCE(r.name, 'Tanpa Ruangan') as room_name,
           a.type, COUNT(a.id) as total
    FROM assets a
    LEFT JOIN rooms r ON r.id = a.room_id
    LEFT JOIN buildings b ON b.id = a.building_id
    WHERE $sem_where_sql
    GROUP BY b.id, b.name, r.id, r.name, a.type
    ORDER BY b.name, r.name
");
$stmt->execute($sem_params);
$by_room_type = $stmt->fetchAll();

$room_pivot = [];
$room_totals = [];
$room_type_used = [];
foreach ($by_room_type as $row) {
    $b = $row['building_name'];
    $r = $row['room_name'];
    $t = $row['type'];
    $cnt = (int)$row['total'];
    if (!isset($room_pivot[$b][$r])) $room_pivot[$b][$r] = [];
    $room_pivot[$b][$r][$t] = $cnt;
    $room_totals[$b][$r] = ($room_totals[$b][$r] ?? 0) + $cnt;
    if ($cnt > 0) $room_type_used[$t] = true;
}

$room_pivot_types = [];
foreach ($type_labels as $k => $v) {
    if (!empty($room_type_used[$k])) $room_pivot_types[$k] = $v;
}

$by_room = [];
foreach ($room_pivot as $b => $rooms) {
    foreach ($rooms as $r => $counts) {
        $by_room[] = ['building_name' => $b, 'room_name' => $r];
    }
}

$stmt = $db->prepare("
    SELECT a.type, COUNT(a.id) as total
    FROM assets a
    WHERE $sem_where_sql
    GROUP BY a.type
");
$stmt->execute($sem_params);
$by_type_raw = $stmt->fetchAll();
$by_type_counts = [];
foreach ($by_type_raw as $row) {
    $by_type_counts[$row['type']] = (int)$row['total'];
}
$by_type = [];
foreach ($type_labels as $k => $v) {
    $by_type[] = [
        'key'   => $k,
        'label' => $v,
        'total' => $by_type_counts[$k] ?? 0
    ];
}
$by_type_chart = array_values(array_filter($by_type, function($t){ return $t['total'] > 0; }));

$sem_total_assets = count($semester_data);

function klasifikasiMasalahLogbook($teks) {
    $teks = strtolower($teks);
    $kategori = [
        'PC/Komputer' => ['pc','komputer','cpu','monitor','layar','hang','restart','blue screen','lemot','lambat','mati total','tidak nyala','windows','startup'],
        'Printer'     => ['printer','print','cetak','toner','catridge','cartridge','paper jam','kertas nyangkut','dot matrix','epson','canon','laserjet'],
        'Mouse'       => ['mouse','kursor','klik kanan','klik kiri','scroll'],
        'Keyboard'    => ['keyboard','tombol','ketikan','huruf tidak muncul'],
    ];
    foreach ($kategori as $nama => $keywords) {
        foreach ($keywords as $kw) {
            if (str_contains($teks, $kw)) return $nama;
        }
    }
    return 'Lain-lain';
}

$stmt = $db->prepare("
    SELECT subject, masalah
    FROM logbook
    WHERE tanggal_lapor BETWEEN ? AND ?
");
$stmt->execute([substr($sem_start, 0, 10), substr($sem_end, 0, 10)]);
$logbook_rows = $stmt->fetchAll();

$klas_labels = ['PC/Komputer', 'Printer', 'Mouse', 'Keyboard', 'Lain-lain'];
$klas_counts = array_fill_keys($klas_labels, 0);

foreach ($logbook_rows as $row) {
    $teks = ($row['subject'] ?? '') . ' ' . ($row['masalah'] ?? '');
    $klas_counts[klasifikasiMasalahLogbook($teks)]++;
}
$klas_total = array_sum($klas_counts);

$stmt = $db->prepare("
    SELECT ml.*, a.asset_code, a.name as asset_name, u.name as user_name
    FROM maintenance_logs ml
    JOIN assets a ON a.id = ml.asset_id
    JOIN users u ON u.id = ml.performed_by
    WHERE ml.performed_at BETWEEN ? AND ?
    ORDER BY ml.performed_at DESC
");
$stmt->execute([$sem_start, $sem_end]);
$sem_maintenance = $stmt->fetchAll();

function klasifikasiMaintenance($teks) {
    $teks = strtolower($teks);
    $kategori = [
        'Pendaftaran Ke Sistem'      => ['daftar','registrasi','register','pendaftaran'],
        'Pembersihan'      => ['bersih','cleaning','debu','lap kipas','servis rutin'],
        'Penambahan RAM'   => ['ram','memory','memori','upgrade ram','tambah ram'],
        'Pergantian'       => ['ganti','tukar','replace','pergantian','sparepart','spare part'],
    ];
    foreach ($kategori as $nama => $keywords) {
        foreach ($keywords as $kw) {
            if (str_contains($teks, $kw)) return $nama;
        }
    }
    return 'Lain-lain';
}

$maint_labels = ['Pendaftaran Ke Sistem', 'Pembersihan', 'Penambahan RAM', 'Pergantian', 'Lain-lain'];
$maint_counts = array_fill_keys($maint_labels, 0);
foreach ($sem_maintenance as $row) {
    $teks = ($row['action'] ?? '') . ' ' . ($row['description'] ?? '');
    $maint_counts[klasifikasiMaintenance($teks)]++;
}
$maint_total = array_sum($maint_counts);

$stmt = $db->prepare("
    SELECT ll.*, a.asset_code, a.name as asset_name, u.name as user_name
    FROM location_logs ll
    JOIN assets a ON a.id = ll.asset_id
    JOIN users u ON u.id = ll.moved_by
    WHERE ll.moved_at BETWEEN ? AND ?
    ORDER BY ll.moved_at DESC
");
$stmt->execute([$sem_start, $sem_end]);
$sem_locations = $stmt->fetchAll();

// ── DATA MANUAL ──────────────────────────────────────────────────────
$man_kategori = $_GET['man_kategori'] ?? '';
$man_sumber   = $_GET['man_sumber'] ?? '';

$man_where = ["1=1"];
$man_params = [];
if ($man_kategori) { $man_where[] = "kategori = ?"; $man_params[] = $man_kategori; }
if ($man_sumber)   { $man_where[] = "sumber = ?";   $man_params[] = $man_sumber; }
$man_where_sql = implode(' AND ', $man_where);

$stmt = $db->prepare("SELECT * FROM manual_data WHERE $man_where_sql ORDER BY kategori, bagian, jenis_hardware");
$stmt->execute($man_params);
$manual_rows = $stmt->fetchAll();

$manual_kategori_list = $db->query("SELECT DISTINCT kategori FROM manual_data ORDER BY kategori")->fetchAll(PDO::FETCH_COLUMN);
$manual_sumber_list   = $db->query("SELECT DISTINCT sumber FROM manual_data ORDER BY sumber")->fetchAll(PDO::FETCH_COLUMN);

$manual_bagian_pairs = [];
foreach ($manual_rows as $r) {
    $manual_bagian_pairs[$r['kategori'] . '|' . $r['bagian']] = true;
}
$manual_bagian_count = count($manual_bagian_pairs);

$chart_palette = ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#e74a3b','#858796','#5a5c69','#2c9faf','#f8a51b','#6f42c1'];

function klasifikasiHardwareManual($teks) {
    $teks = strtolower($teks);
    $printer_keywords = ['printer','print','cetak','epson','tsc','zebra','laserjet','canon'];
    foreach ($printer_keywords as $kw) {
        if (str_contains($teks, $kw)) return 'Printer';
    }
    return 'PC/Komputer';
}

$manual_pivot = [];
$manual_row_totals = [];
$manual_hw_used = [];
foreach ($manual_rows as $r) {
    $k = $r['kategori']; $hw = klasifikasiHardwareManual($r['jenis_hardware']); $j = (int)$r['jumlah'];
    if (!isset($manual_pivot[$k])) $manual_pivot[$k] = [];
    $manual_pivot[$k][$hw] = ($manual_pivot[$k][$hw] ?? 0) + $j;
    $manual_row_totals[$k] = ($manual_row_totals[$k] ?? 0) + $j;
    $manual_hw_used[$hw] = true;
}
$manual_hw_columns = array_keys($manual_hw_used);
sort($manual_hw_columns);
$manual_grand_total = array_sum(array_column($manual_rows, 'jumlah'));

$manual_groups = ['PC/Komputer' => [], 'Printer' => []];
foreach ($manual_rows as $r) {
    $grp = klasifikasiHardwareManual($r['jenis_hardware']);
    $manual_groups[$grp][] = $r;
}

// ── Build chart data per group ──
// by_kategori: agregasi per kategori (induk), bukan per ruangan
// Palet warna dengan kontras tinggi, tidak nyaru satu sama lain
$chart_palette_kontras = [
    '#e6194b', '#3cb44b', '#4363d8', '#f58231', '#911eb4',
    '#42d4f4', '#f032e6', '#bfef45', '#469990', '#9A6324',
    '#800000', '#000075', '#a9a9a9', '#fabed4', '#dcbeff'
];

$manual_group_charts = [];
foreach ($manual_groups as $grp_name => $rows) {
    if (!$rows) continue;

    // agregasi per kategori/induk (dipakai untuk chart & label)
    $by_kategori = [];
    foreach ($rows as $r) {
        $kat = $r['kategori'];
        $by_kategori[$kat] = ($by_kategori[$kat] ?? 0) + (int)$r['jumlah'];
    }
    arsort($by_kategori);

    // warna konsisten per kategori, kontras tinggi
    $colors = [];
    $ci = 0;
    foreach ($by_kategori as $kat => $total) {
        $colors[$kat] = $chart_palette_kontras[$ci % count($chart_palette_kontras)];
        $ci++;
    }

    $manual_group_charts[$grp_name] = [
        'id'          => 'chartManualGroup' . preg_replace('/[^a-zA-Z0-9]/', '', $grp_name),
        'by_kategori' => $by_kategori,
        'colors'      => $colors,
        'total'       => array_sum($by_kategori),
    ];
}

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <h4 class="fw-bold mb-0"><i class="bi bi-file-earmark-bar-graph me-2 text-primary"></i>Laporan</h4>
    <button class="btn btn-outline-primary btn-sm" onclick="window.print()">
        <i class="bi bi-printer me-1"></i>Print Laporan
    </button>
</div>

<ul class="nav nav-tabs mb-3 no-print" id="laporanTab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="tab-laporan-btn" type="button" data-tab-target="tab-laporan">
            <i class="bi bi-table me-1"></i>Laporan
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="tab-semester-btn" type="button" data-tab-target="tab-semester">
            <i class="bi bi-bar-chart-line me-1"></i>Laporan Semester
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="tab-manual-btn" type="button" data-tab-target="tab-manual">
            <i class="bi bi-journal-text me-1"></i>Data Manual (Excel)
        </button>
    </li>
</ul>

<div class="tab-content" id="laporanTabContent">

<!-- ══ TAB 1: LAPORAN ══ -->
<div class="tab-pane show active" id="tab-laporan" role="tabpanel">

<div class="card mb-3 no-print">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-6 col-md-2">
                <label class="form-label form-label-sm">Jenis Laporan</label>
                <select name="report_type" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="assets" <?= $report_type==='assets'?'selected':'' ?>>Inventaris Aset</option>
                    <option value="maintenance" <?= $report_type==='maintenance'?'selected':'' ?>>History Maintenance</option>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label form-label-sm">Tipe Hardware</label>
                <select name="type" class="form-select form-select-sm">
                    <option value="">Semua</option>
                    <?php foreach ($type_labels as $k=>$v): ?>
                    <option value="<?= $k ?>" <?= $type===$k?'selected':'' ?>><?= $v ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($report_type === 'assets'): ?>
            <div class="col-6 col-md-2">
                <label class="form-label form-label-sm">Kondisi</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">Semua</option>
                    <option value="baik" <?= $status==='baik'?'selected':'' ?>>Baik</option>
                    <option value="perlu_perhatian" <?= $status==='perlu_perhatian'?'selected':'' ?>>Perlu Perhatian</option>
                    <option value="rusak" <?= $status==='rusak'?'selected':'' ?>>Rusak</option>
                </select>
            </div>
            <?php endif; ?>
            <div class="col-6 col-md-2">
                <label class="form-label form-label-sm">Gedung</label>
                <select name="building" class="form-select form-select-sm">
                    <option value="">Semua</option>
                    <?php foreach ($buildings as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= $building==$b['id']?'selected':'' ?>><?= clean($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($report_type === 'maintenance'): ?>
            <div class="col-6 col-md-2">
                <label class="form-label form-label-sm">Dari Tanggal</label>
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?= clean($date_from) ?>">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label form-label-sm">Sampai Tanggal</label>
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?= clean($date_to) ?>">
            </div>
            <?php endif; ?>
            <div class="col-auto d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-search"></i> Filter</button>
                <a href="?report_type=<?= clean($report_type) ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x"></i></a>
            </div>
        </form>
    </div>
</div>

<div class="mb-3" id="print-header">
    <h5 class="fw-bold"><?= APP_NAME ?></h5>
    <div class="text-muted small">
        Laporan: <?= $report_type === 'assets' ? 'Inventaris Aset' : 'History Maintenance' ?>
        &bull; Dicetak: <?= date('d M Y H:i') ?>
        &bull; Oleh: <?= clean(currentUser()['name']) ?>
    </div>
    <hr>
</div>

<?php if ($report_type === 'assets'): ?>
<div class="card">
    <div class="card-header bg-light d-flex justify-content-between">
        <span><i class="bi bi-hdd-stack me-2"></i>Inventaris Aset</span>
        <span class="badge bg-primary"><?= count($assets) ?> aset</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-sm mb-0">
                <thead>
                    <tr>
                        <th>No</th><th>Kode Aset</th><th>Nama</th><th>Tipe</th>
                        <th>Brand/Model</th><th>S/N</th><th>Kondisi</th><th>Gedung</th><th>Ruangan</th><th>Terdaftar</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($assets): $no=1; foreach ($assets as $a): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= clean($a['asset_code']) ?></strong></td>
                    <td><?= clean($a['name'] ?? '-') ?></td>
                    <td><?= clean($type_labels[$a['type']] ?? '-') ?></td>
                    <td><?= clean(($a['brand']??'') . ' ' . ($a['model']??'')) ?></td>
                    <td><small><?= clean($a['serial_number'] ?? '-') ?></small></td>
                    <td>
                        <?php $c = $a['condition_status'];
                        $cl = ['baik'=>'Baik','perlu_perhatian'=>'Perlu Perhatian','rusak'=>'Rusak']; ?>
                        <span class="badge badge-<?= $c ?>"><?= $cl[$c] ?></span>
                    </td>
                    <td><?= clean($a['building_name'] ?? '-') ?></td>
                    <td><?= clean($a['room_name'] ?? '-') ?></td>
                    <td><small><?= $a['registered_at'] ? date('d/m/y', strtotime($a['registered_at'])) : '-' ?></small></td>
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="10" class="text-center py-4 text-muted">Tidak ada data</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php else: ?>
<div class="card">
    <div class="card-header bg-light d-flex justify-content-between">
        <span><i class="bi bi-tools me-2"></i>History Maintenance</span>
        <span class="badge bg-primary"><?= count($maintenance) ?> kegiatan</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-sm mb-0">
                <thead>
                    <tr><th>No</th><th>Tanggal</th><th>Kode Aset</th><th>Nama Aset</th><th>Tipe</th><th>Lokasi</th><th>Kegiatan</th><th>Keterangan</th><th>Oleh</th></tr>
                </thead>
                <tbody>
                <?php if ($maintenance): $no=1; foreach ($maintenance as $m): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><small><?= date('d/m/y H:i', strtotime($m['performed_at'])) ?></small></td>
                    <td><strong><?= clean($m['asset_code']) ?></strong></td>
                    <td><?= clean($m['asset_name'] ?? '-') ?></td>
                    <td><small><?= clean($type_labels[$m['asset_type']] ?? '-') ?></small></td>
                    <td><small><?= clean(($m['building_name']??'-') . ($m['room_name'] ? ' / '.$m['room_name'] : '')) ?></small></td>
                    <td><?= clean($m['action']) ?></td>
                    <td><small class="text-muted"><?= clean($m['description'] ?? '-') ?></small></td>
                    <td><?= clean($m['user_name']) ?></td>
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="9" class="text-center py-4 text-muted">Tidak ada data</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

</div>
<!-- END TAB 1 -->

<!-- ══ TAB 2: LAPORAN SEMESTER ══ -->
<div class="tab-pane" id="tab-semester" role="tabpanel">

    <div class="card mb-3 no-print">
        <div class="card-body">
            <form method="GET" class="row g-2 align-items-end" id="semesterFilterForm">
                <input type="hidden" name="report_type" value="<?= clean($report_type) ?>">
                <div class="col-6 col-md-2">
                    <label class="form-label form-label-sm">Tahun</label>
                    <input type="number" name="sem_year" class="form-control form-control-sm" value="<?= (int)$sem_year ?>" min="2000" max="2100">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label form-label-sm">Semester</label>
                    <select name="sem_semester" class="form-select form-select-sm">
                        <option value="all" <?= $sem_semester=='all'?'selected':'' ?>>Semua</option>
                        <option value="1" <?= $sem_semester=='1'?'selected':'' ?>>Semester 1 (Jan - Jun)</option>
                        <option value="2" <?= $sem_semester=='2'?'selected':'' ?>>Semester 2 (Jul - Des)</option>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label form-label-sm">Tipe Hardware</label>
                    <select name="sem_type" class="form-select form-select-sm">
                        <option value="">Semua</option>
                        <?php foreach ($type_labels as $k=>$v): ?>
                        <option value="<?= $k ?>" <?= $sem_type===$k?'selected':'' ?>><?= $v ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label form-label-sm">Gedung</label>
                    <select name="sem_building" class="form-select form-select-sm">
                        <option value="">Semua</option>
                        <?php foreach ($buildings as $b): ?>
                        <option value="<?= $b['id'] ?>" <?= $sem_building==$b['id']?'selected':'' ?>><?= clean($b['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-auto d-flex gap-1">
                    <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-search"></i> Filter</button>
                    <a href="?report_type=<?= clean($report_type) ?>#semester" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x"></i></a>
                </div>
            </form>
        </div>
    </div>

    <div class="mb-3" id="print-header-semester">
        <h5 class="fw-bold"><?= APP_NAME ?></h5>
        <div class="text-muted small">
            Laporan Semester: Distribusi Hardware Terdaftar &bull; <?= clean($sem_label) ?>
            &bull; Dicetak: <?= date('d M Y H:i') ?>
            &bull; Oleh: <?= clean(currentUser()['name']) ?>
        </div>
        <hr>
    </div>

    <div class="row g-2 mb-3 no-print">
        <div class="col-6 col-md-3">
            <div class="card text-center">
                <div class="card-body py-2">
                    <div class="text-muted small">Total Aset (periode ini)</div>
                    <div class="fs-4 fw-bold text-primary"><?= $sem_total_assets ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card text-center">
                <div class="card-body py-2">
                    <div class="text-muted small">Jumlah Gedung</div>
                    <div class="fs-4 fw-bold"><?= count($by_building) ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card text-center">
                <div class="card-body py-2">
                    <div class="text-muted small">Jumlah Ruangan</div>
                    <div class="fs-4 fw-bold"><?= count($by_room) ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card text-center">
                <div class="card-body py-2">
                    <div class="text-muted small">Periode</div>
                    <div class="fs-6 fw-bold"><?= clean($sem_label) ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header bg-light"><i class="bi bi-hdd-stack me-2"></i>Indikator Jumlah per Tipe Hardware (Terdaftar)</div>
        <div class="card-body">
            <div class="row g-2 text-center">
                <?php
                $type_icons = [
                    'komputer' => 'bi-pc-display',
                    'laptop'   => 'bi-laptop',
                    'printer'  => 'bi-printer',
                    'scanner'  => 'bi-scan',
                    'server'   => 'bi-hdd-rack',
                    'network'  => 'bi-diagram-3',
                    'lainnya'  => 'bi-box-seam',
                ];
                foreach ($by_type as $t):
                    $icon = $type_icons[$t['key']] ?? 'bi-hdd';
                ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="border rounded p-2 h-100">
                        <i class="bi <?= $icon ?> fs-3 text-primary"></i>
                        <div class="fs-3 fw-bold"><?= $t['total'] ?></div>
                        <div class="text-muted small"><?= clean($t['label']) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="page-break"></div>

    <div class="row g-3 mb-3 chart-row-1">
        <div class="col-6 chart-col-half">
            <div class="card chart-card-fixed">
                <div class="card-header bg-light"><i class="bi bi-building me-2"></i>Distribusi per Gedung</div>
                <div class="card-body">
                    <?php if ($by_building): ?>
                    <div class="chart-pie-wrap" style="height: 600px;">
                        <canvas id="chartBuilding"></canvas>
                    </div>
                    <?php else: ?>
                    <div class="text-center text-muted py-4">Tidak ada data</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-6 chart-col-half">
            <div class="card chart-card-fixed">
                <div class="card-header bg-light"><i class="bi bi-hdd-stack me-2"></i>Distribusi per Tipe Hardware</div>
                <div class="card-body">
                    <?php if ($by_type_chart): ?>
                    <div class="chart-pie-wrap" style="height: 600px;">
                        <canvas id="chartType"></canvas>
                    </div>
                    <?php else: ?>
                    <div class="text-center text-muted py-4">Tidak ada data</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="page-break"></div>

    <div class="row g-3 mb-3">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-light"><i class="bi bi-door-open me-2"></i>Distribusi Hardware Terdaftar (per Ruangan)</div>
                <div class="card-body p-0">
                    <?php if ($room_pivot): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm mb-0 text-center align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>No</th>
                                    <th class="text-start">Bagian / Ruangan</th>
                                    <?php foreach ($room_pivot_types as $lbl): ?>
                                    <th><?= clean($lbl) ?></th>
                                    <?php endforeach; ?>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($room_pivot as $building_name => $rooms): ?>
                                <tr class="table-secondary">
                                    <td colspan="<?= 3 + count($room_pivot_types) ?>" class="text-start fw-bold">
                                        <?= clean($building_name) ?>
                                    </td>
                                </tr>
                                <?php $no = 1; foreach ($rooms as $room_name => $counts): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="text-start"><?= clean($room_name) ?></td>
                                    <?php foreach ($room_pivot_types as $k => $lbl): ?>
                                    <td><?= ($counts[$k] ?? 0) ?: '' ?></td>
                                    <?php endforeach; ?>
                                    <td class="fw-bold"><?= $room_totals[$building_name][$room_name] ?? 0 ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center text-muted py-4">Tidak ada data</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="klas-maint-group">
<div class="card mb-3">
    <div class="card-header bg-light d-flex justify-content-between">
        <span><i class="bi bi-tags me-2"></i>Klasifikasi Masalah Logbook - <?= clean($sem_label) ?></span>
        <span class="badge bg-primary"><?= $klas_total ?> laporan</span>
    </div>
    <div class="card-body">
        <?php if ($klas_total): ?>
        <div style="height: 240px;">
            <canvas id="chartKlasifikasi"></canvas>
        </div>
        <?php else: ?>
        <div class="text-center text-muted py-4">Tidak ada data logbook pada periode ini</div>
        <?php endif; ?>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header bg-light d-flex justify-content-between">
        <span><i class="bi bi-tools me-2"></i>Maintenance - <?= clean($sem_label) ?></span>
        <span class="badge bg-primary"><?= $maint_total ?> kegiatan</span>
    </div>
    <div class="card-body">
        <?php if ($maint_total): ?>
        <div style="height: 240px;">
            <canvas id="chartMaintenance"></canvas>
        </div>
        <?php else: ?>
        <div class="text-center text-muted py-4">Tidak ada kegiatan maintenance pada periode ini</div>
        <?php endif; ?>
    </div>
</div>
</div>

    <div class="card mb-3">
        <div class="card-header bg-light d-flex justify-content-between">
            <span><i class="bi bi-arrow-left-right me-2"></i>Optimalisasi (Pindah Lokasi) - <?= clean($sem_label) ?></span>
            <span class="badge bg-primary"><?= count($sem_locations) ?> kegiatan</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-sm mb-0">
                    <thead>
                        <tr><th>No</th><th>Tanggal</th><th>Kode Aset</th><th>Nama Aset</th><th>Lokasi Baru</th><th>Catatan</th><th>Oleh</th></tr>
                    </thead>
                    <tbody>
                    <?php if ($sem_locations): $no=1; foreach ($sem_locations as $l): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><small><?= date('d/m/y H:i', strtotime($l['moved_at'])) ?></small></td>
                            <td><strong><?= clean($l['asset_code']) ?></strong></td>
                            <td><?= clean($l['asset_name'] ?? '-') ?></td>
                            <td><?= clean($l['building_name'] ?? '-') ?><?= $l['room_name'] ? ' / '.clean($l['room_name']) : '' ?></td>
                            <td><small class="text-muted"><?= clean($l['notes'] ?? '-') ?></small></td>
                            <td><?= clean($l['user_name']) ?></td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Tidak ada kegiatan pindah lokasi pada periode ini</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- END TAB 2 -->

<!-- ══ TAB 3: DATA MANUAL ══ -->
<div class="tab-pane" id="tab-manual" role="tabpanel">

    <div class="alert alert-warning no-print">
        <i class="bi bi-info-circle me-1"></i>
        Data di tab ini berasal dari rekap manual Excel (sebelum sistem berjalan), disimpan di
        tabel <code>manual_data</code> — <strong>terpisah</strong> dari tabel <code>assets</code>.
    </div>

    <div class="card mb-3 no-print">
        <div class="card-body">
            <form method="GET" class="row g-2 align-items-end">
                <input type="hidden" name="report_type" value="<?= clean($report_type) ?>">
                <div class="col-6 col-md-3">
                    <label class="form-label form-label-sm">Kategori</label>
                    <select name="man_kategori" class="form-select form-select-sm">
                        <option value="">Semua</option>
                        <?php foreach ($manual_kategori_list as $k): ?>
                        <option value="<?= clean($k) ?>" <?= $man_kategori===$k?'selected':'' ?>><?= clean($k) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label form-label-sm">Sumber</label>
                    <select name="man_sumber" class="form-select form-select-sm">
                        <option value="">Semua</option>
                        <?php foreach ($manual_sumber_list as $s): ?>
                        <option value="<?= clean($s) ?>" <?= $man_sumber===$s?'selected':'' ?>><?= clean($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-auto d-flex gap-1">
                    <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-search"></i> Filter</button>
                    <a href="?report_type=<?= clean($report_type) ?>#manual" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x"></i></a>
                </div>
            </form>
        </div>
    </div>

    <div class="mb-3" id="print-header-manual">
        <h5 class="fw-bold"><?= APP_NAME ?></h5>
        <div class="text-muted small">
            Laporan: Distribusi Hardware Manual &bull; Dicetak: <?= date('d M Y H:i') ?>
            &bull; Oleh: <?= clean(currentUser()['name']) ?>
        </div>
        <hr>
    </div>

    <div class="row g-2 mb-3 no-print">
        <div class="col-6 col-md-4">
            <div class="card text-center">
                <div class="card-body py-2">
                    <div class="text-muted small">Total Unit (Manual)</div>
                    <div class="fs-4 fw-bold text-primary"><?= $manual_grand_total ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4">
            <div class="card text-center">
                <div class="card-body py-2">
                    <div class="text-muted small">Jumlah Bagian/Ruangan</div>
                    <div class="fs-4 fw-bold"><?= $manual_bagian_count ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ══ 2 Chart + Keterangan per Induk/Kategori ══ -->
    <?php if ($manual_group_charts): ?>
    <div class="row g-3 mb-3">
        <?php foreach ($manual_group_charts as $grp_name => $grp): ?>
        <div class="col-12 col-md-6">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-pie-chart me-2"></i><?= clean($grp_name) ?></span>
                    <span class="badge bg-primary"><?= $grp['total'] ?> unit</span>
                </div>
                <div class="card-body">
    <div class="card-body">
    <div style="height: 280px;">
        <canvas id="<?= $grp['id'] ?>"></canvas>
    </div>
</div>
<!-- Keterangan: warna + induk/kategori + jumlah + persentase -->
<div class="card-footer p-0">
    <table class="table table-sm table-bordered mb-0" style="font-size:12px;">
        <thead class="table-light">
            <tr>
                <th style="width:36px;" class="text-center">Warna</th>
                <th>Induk / Kategori</th>
                <th class="text-end" style="width:55px;">Jumlah</th>
                <th class="text-end" style="width:55px;">%</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($grp['by_kategori'] as $kat => $jml):
                $warna = $grp['colors'][$kat] ?? '#858796';
                $persen = $grp['total'] > 0 ? round(($jml / $grp['total']) * 100) : 0;
            ?>
            <tr>
                <td class="text-center align-middle">
                    <div style="width:18px;height:18px;border-radius:3px;background:<?= $warna ?>;margin:0 auto;"></div>
                </td>
                <td class="align-middle"><?= clean($kat) ?></td>
                <td class="text-end fw-bold align-middle"><?= $jml ?></td>
                <td class="text-end align-middle"><?= $persen ?>%</td>
            </tr>
            <?php endforeach; ?>
            <tr class="table-secondary">
                <td colspan="2" class="text-end fw-bold">Total</td>
                <td class="text-end fw-bold"><?= $grp['total'] ?></td>
                <td class="text-end fw-bold">100%</td>
            </tr>
        </tbody>
    </table>
</div>
</div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="page-break"></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header bg-light"><i class="bi bi-journal-text me-2"></i>Distribusi Hardware Manual</div>
        <div class="card-body p-0">
            <?php if ($manual_pivot): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-sm mb-0 text-center align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th class="text-start">Induk / Kategori</th>
                            <?php foreach ($manual_hw_columns as $hw): ?>
                            <th><?= clean($hw) ?></th>
                            <?php endforeach; ?>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; foreach ($manual_pivot as $kategori => $counts): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td class="text-start fw-bold"><?= clean($kategori) ?></td>
                            <?php foreach ($manual_hw_columns as $hw): ?>
                            <td><?= ($counts[$hw] ?? 0) ?: '' ?></td>
                            <?php endforeach; ?>
                            <td class="fw-bold"><?= $manual_row_totals[$kategori] ?? 0 ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="table-dark">
                        <td colspan="<?= 2 + count($manual_hw_columns) ?>" class="text-end fw-bold">TOTAL KESELURUHAN</td>
                        <td class="fw-bold"><?= $manual_grand_total ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center text-muted py-4">Tidak ada data manual</div>
            <?php endif; ?>
        </div>
    </div>

</div>
<!-- END TAB 3 -->

</div>
<!-- END TAB CONTENT -->

<style>
.tab-pane { display: none; }
.tab-pane.active { display: block; }

.chart-pie-wrap {
    max-width: 650px;
    margin: 0 auto;
}
.chart-card-fixed {
    min-height: 650px;
}

.page-break { display: none; }

@media print {
    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    .page-break {
        display: block;
        page-break-before: always;
        break-before: page;
    }
    .no-print { display: none !important; }
    .card { box-shadow: none !important; border: 1px solid #ddd !important; page-break-inside: avoid; break-inside: avoid; }
    .navbar { display: none !important; }
    body { padding: 0 !important; }
    .container-fluid { padding: 8px !important; }
    .table { font-size: 9pt; }
    #print-header, #print-header-semester, #print-header-manual { display: block !important; }
    a { color: inherit !important; text-decoration: none !important; }
    .tab-pane { display: none; }
    .tab-pane.active { display: block !important; }
    .chart-row-1 { page-break-inside: avoid; break-inside: avoid; }
    .chart-row-1 .chart-col-half {
        width: 50% !important;
        max-width: 50% !important;
        flex: 0 0 50% !important;
    }
    .chart-card-fixed { height: auto !important; min-height: 300px; overflow: hidden; }
    .chart-pie-wrap { max-width: 100%; width: 100%; height: 300px !important; margin: 0; overflow: hidden; }
    canvas { max-width: 100% !important; max-height: 100% !important; }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
    if (typeof Chart === 'undefined') {
        document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"><\/script>');
    }
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var palette = ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#e74a3b','#858796','#5a5c69','#2c9faf','#f8a51b','#6f42c1'];
    var chartsInitialized = false;
    var chartInstances = [];

    // Plugin: label angka di luar pie/doughnut dengan leader line
    var externalLabelsPlugin = {
    id: 'externalLabels',
    afterDraw: function (chart) {
        if (chart.config.type !== 'pie' && chart.config.type !== 'doughnut') return;
        var ctx = chart.ctx;
        var meta = chart.getDatasetMeta(0);
        var dataset = chart.data.datasets[0];
        var total = dataset.data.reduce(function (a, b) { return a + b; }, 0);
        if (!total) return;

        // Kumpulkan dulu semua titik label per sisi (kiri/kanan)
        var rightLabels = [];
        var leftLabels = [];

        meta.data.forEach(function (arc, i) {
            var value = dataset.data[i];
            if (!value) return;
            var percentage = Math.round((value / total) * 100);
            if ((value / total) * 100 < 1.5) return;

            var angle = (arc.startAngle + arc.endAngle) / 2;
            var radius = arc.outerRadius;
            var isRight = Math.cos(angle) >= 0;

            var x1 = arc.x + Math.cos(angle) * radius;
            var y1 = arc.y + Math.sin(angle) * radius;
            var y2 = arc.y + Math.sin(angle) * (radius + 14);

            var item = {
                x1: x1, y1: y1, y2: y2,
                cx: arc.x, cy: arc.y, radius: radius,
                label: chart.data.labels[i] || '',
                text: value + ' (' + percentage + '%)'
            };
            if (isRight) rightLabels.push(item); else leftLabels.push(item);
        });

        // Fungsi: urutkan by y2, lalu geser (push) label yang jaraknya < minGap
        function resolveCollisions(labels, minGap) {
            labels.sort(function (a, b) { return a.y2 - b.y2; });
            for (var i = 1; i < labels.length; i++) {
                if (labels[i].y2 - labels[i - 1].y2 < minGap) {
                    labels[i].y2 = labels[i - 1].y2 + minGap;
                }
            }
            // dorong balik dari bawah ke atas kalau ada yang kepentok batas bawah chart
            for (var j = labels.length - 2; j >= 0; j--) {
                if (labels[j + 1].y2 - labels[j].y2 < minGap) {
                    labels[j].y2 = labels[j + 1].y2 - minGap;
                }
            }
            return labels;
        }

        var minGap = 30; // jarak vertikal minimum antar label (2 baris teks)
        resolveCollisions(rightLabels, minGap);
        resolveCollisions(leftLabels, minGap);

        function drawLabel(item, isRight) {
            var x2 = item.cx + Math.cos(Math.atan2(item.y1 - item.cy, item.x1 - item.cx)) * (item.radius + 14);
            // pakai y2 yang sudah di-resolve, x2 dihitung ulang biar garis tetap nyambung wajar
            var elbowX = item.x1 + (isRight ? 14 : -14);
            var x3 = elbowX + (isRight ? 14 : -14);

            ctx.beginPath();
            ctx.moveTo(item.x1, item.y1);
            ctx.lineTo(elbowX, item.y2);
            ctx.lineTo(x3, item.y2);
            ctx.strokeStyle = '#999';
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(item.x1, item.y1, 2, 0, Math.PI * 2);
            ctx.fillStyle = '#999';
            ctx.fill();

            var textX = x3 + (isRight ? 4 : -4);
            ctx.textAlign = isRight ? 'left' : 'right';
            ctx.textBaseline = 'middle';

            ctx.font = 'bold 11px sans-serif';
            ctx.fillStyle = '#333';
            ctx.fillText(item.label, textX, item.y2 - 7);

            ctx.font = '10px sans-serif';
            ctx.fillStyle = '#666';
            ctx.fillText(item.text, textX, item.y2 + 7);
        }

        ctx.save();
        rightLabels.forEach(function (it) { drawLabel(it, true); });
        leftLabels.forEach(function (it) { drawLabel(it, false); });
        ctx.restore();
    }
};

    // Plugin: label angka di ujung bar
    var barValueLabelsPlugin = {
        id: 'barValueLabels',
        afterDatasetsDraw: function (chart) {
            if (chart.config.type !== 'bar') return;
            var ctx = chart.ctx;
            chart.data.datasets.forEach(function (dataset, dsIndex) {
                var meta = chart.getDatasetMeta(dsIndex);
                meta.data.forEach(function (bar, i) {
                    var value = dataset.data[i];
                    ctx.save();
                    ctx.font = 'bold 10px sans-serif';
                    ctx.fillStyle = '#333';
                    if (chart.options.indexAxis === 'y') {
                        ctx.textAlign = 'left';
                        ctx.textBaseline = 'middle';
                        ctx.fillText(value, bar.x + 6, bar.y);
                    } else {
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'bottom';
                        ctx.fillText(value, bar.x, bar.y - 4);
                    }
                    ctx.restore();
                });
            });
        }
    };

    function initSemesterCharts() {
        if (chartsInitialized) return;
        if (typeof Chart === 'undefined') { setTimeout(initSemesterCharts, 200); return; }
        var bCanvas = document.getElementById('chartBuilding');
        var tCanvas = document.getElementById('chartType');
        var kCanvas = document.getElementById('chartKlasifikasi');
        var mCanvas = document.getElementById('chartMaintenance');
        if (!bCanvas && !tCanvas && !kCanvas && !mCanvas) return;
        chartsInitialized = true;

        <?php if ($by_building): ?>
        chartInstances.push(new Chart(document.getElementById('chartBuilding'), {
            type: 'pie',
            data: {
                labels: <?= json_encode(array_column($by_building, 'building_name')) ?>,
                datasets: [{ data: <?= json_encode(array_map('intval', array_column($by_building, 'total'))) ?>, backgroundColor: palette }]
            },
            options: {
    responsive: true, maintainAspectRatio: false,
    layout: { padding: { left: 110, right: 110, top: 50, bottom: 50 } },
    plugins: { legend: { position: 'bottom', labels: { padding: 20 } } }
},
            plugins: [externalLabelsPlugin]
        }));
        <?php endif; ?>

        <?php if ($by_type_chart): ?>
        chartInstances.push(new Chart(document.getElementById('chartType'), {
            type: 'doughnut',
            data: {
                labels: <?= json_encode(array_column($by_type_chart, 'label')) ?>,
                datasets: [{ data: <?= json_encode(array_map('intval', array_column($by_type_chart, 'total'))) ?>, backgroundColor: palette }]
            },
            options: {
    responsive: true, maintainAspectRatio: false,
    layout: { padding: { left: 110, right: 110, top: 50, bottom: 50 } },
    plugins: { legend: { position: 'bottom', labels: { padding: 20 } } }
},
plugins: [externalLabelsPlugin]
        }));
        <?php endif; ?>

        <?php if ($maint_total): ?>
        chartInstances.push(new Chart(document.getElementById('chartMaintenance'), {
            type: 'bar',
            data: {
                labels: <?= json_encode($maint_labels) ?>,
                datasets: [{ label: 'Jumlah Kegiatan', data: <?= json_encode(array_values($maint_counts)) ?>, backgroundColor: ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#858796'] }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
            plugins: [barValueLabelsPlugin]
        }));
        <?php endif; ?>

        <?php if ($klas_total): ?>
        chartInstances.push(new Chart(document.getElementById('chartKlasifikasi'), {
            type: 'bar',
            data: {
                labels: <?= json_encode($klas_labels) ?>,
                datasets: [{ label: 'Jumlah Masalah', data: <?= json_encode(array_values($klas_counts)) ?>, backgroundColor: ['#4e73df','#1cc88a','#f6c23e','#e74a3b','#858796'] }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
            plugins: [barValueLabelsPlugin]
        }));
        <?php endif; ?>
    }

    var manualChartsInitialized = false;
    function initManualCharts() {
        if (manualChartsInitialized) return;
        if (typeof Chart === 'undefined') { setTimeout(initManualCharts, 200); return; }
        var manualGroups = <?= json_encode(array_values($manual_group_charts)) ?>;
        if (!manualGroups.length) return;
        var firstCanvas = document.getElementById(manualGroups[0].id);
        if (!firstCanvas) return;
        manualChartsInitialized = true;

        manualGroups.forEach(function (grp) {
    var canvas = document.getElementById(grp.id);
    if (!canvas) return;
    var labels = Object.keys(grp.by_kategori);
    var values = labels.map(function (k) { return grp.by_kategori[k]; });
    var colors = labels.map(function (k) { return grp.colors[k]; });
    chartInstances.push(new Chart(canvas, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{ data: values, backgroundColor: colors }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            layout: { padding: 30 },
            plugins: { legend: { display: false } }
        },
        plugins: [externalLabelsPlugin]
    }));
});
    }

    // Tab switcher
    var tabButtons = document.querySelectorAll('#laporanTab [data-tab-target]');
    tabButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            tabButtons.forEach(function (b) { b.classList.remove('active'); });
            document.querySelectorAll('#laporanTabContent .tab-pane').forEach(function (p) { p.classList.remove('active'); });
            btn.classList.add('active');
            var targetId = btn.getAttribute('data-tab-target');
            var targetPane = document.getElementById(targetId);
            if (targetPane) targetPane.classList.add('active');
            if (targetId === 'tab-semester') setTimeout(initSemesterCharts, 30);
            if (targetId === 'tab-manual') setTimeout(initManualCharts, 30);
        });
    });

    if (window.location.hash === '#semester') {
        var semesterBtn = document.querySelector('#tab-semester-btn');
        if (semesterBtn) semesterBtn.click();
    } else if (window.location.hash === '#manual') {
        var manualBtn = document.querySelector('#tab-manual-btn');
        if (manualBtn) manualBtn.click();
    } else {
        setTimeout(initSemesterCharts, 100);
    }

    window.addEventListener('beforeprint', function () {
        initSemesterCharts();
        initManualCharts();
        requestAnimationFrame(function () {
            requestAnimationFrame(function () {
                chartInstances.forEach(function (c) { if (c) c.resize(); });
            });
        });
    });

    if (window.matchMedia) {
        window.matchMedia('print').addEventListener('change', function (mql) {
            if (mql.matches) chartInstances.forEach(function (c) { if (c) c.resize(); });
        });
    }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>